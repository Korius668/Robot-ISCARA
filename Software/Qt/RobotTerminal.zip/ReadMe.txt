Program do przesyłania instrukcji do mikrokontrolera.

Pozwala na komunikację UART z mikrokontrolerem.

Posiada listę instrukcji, które mogą zostać wprowadzone do terminala.

Zaimplementowano wzory kinematyki odwrotnej i prostej pozwalające wyznaczyć współrzędne złączowe i kartezjańskie.

Aplikacja zawsze przesyła komendy ruchu za pomocą współrzędnych złączowych.
